<?php
/* COPYRIGHT
------------------------------------------------------------------  
  Omni Magazine for Drupal 8.x - Version 1.0                           
  Copyright (C) 2016 esors.com All Rights Reserved.           
  @license - Copyrighted Commercial Software                   
------------------------------------------------------------------  
  Theme Name: Omni Magazine                                            
  Author: ESORS                                           
  Date: 15th February 2016                                        
  Website: http://www.esors.com/                              
------------------------------------------------------------------  
  This file may not be redistributed in whole or   
  significant part.                                            
----------------------------------------------------------------*/ 
/**
 * @file
 * Contains \Drupal\omni_custom\Twig\OmniExtension. 
 */

namespace Drupal\omni_custom\Twig;

class OmniExtension extends \Twig_Extension {
  
  /**
   * {@inheritdoc}
   */
  public function getName() {
    return 'omni';
  }

  /**
   * {@inheritdoc}
   */
  public function getFunctions() {
    return array(
      new \Twig_SimpleFunction('remove_image', array($this, 'remove_image'), array('is_safe' => array('html'),)),
      new \Twig_SimpleFunction('remove_image_alter', array($this, 'remove_image_alter'), array('is_safe' => array('html'),)),
      new \Twig_SimpleFunction('background_image', array($this, 'background_image'), array('is_safe' => array('html'),)),
    );
  }

  public function remove_image($str, $type) {
    if ($type=='thumbnail'){
      $pos = strpos($str, '<div class="image-thumbnail">');      
    }

    if ($type=='default'){
      $pos = strpos($str, '<div class="image-default">');      
    }

    if ($pos != false) {
      $start = $pos;
      $end = strpos($str, '</div>', $start) + 6;
      return substr_replace($str,'', $start, $end - $start);
    }  else {
      return '<div class="no-image">'.$str.'</div>';
    }
  }
  
  public function remove_image_alter($str, $type) {

    $image_default = strpos($str, '<div class="image-default">');
    $image_thumbnail = strpos($str, '<div class="image-thumbnail">'); 

    if ($type=='thumbnail') {   

      if ($image_thumbnail != false) {
        $start = $image_thumbnail;
        $end = strpos($str, '</div>', $start) + 6;
        $str = substr_replace($str,'', $start, $end - $start);
      } 

      if ($image_default != false ){
        $pos = strpos($str, '<div class="image-default"></div>'); 

        if ($pos != false) {
          $str = str_replace('<div class="image-default"></div>','',$str);
          return '<div class="no-image">'.$str.'</div>';
        } else {
          return $str;
        }     
      } else {
        return '<div class="no-image">'.$str.'</div>';
      }     
    }

    if ($type=='default') {   

      if ($image_default != false) {
        $start = $image_default;
        $end = strpos($str, '</div>', $start) + 6;
        $str = substr_replace($str,'', $start, $end - $start); 
      }     

      if ($image_thumbnail != false ){
        $pos = strpos($str, '<div class="image-thumbnail"></div>'); 

        if ($pos != false) {
          $str = str_replace('<div class="image-thumbnail"></div>','',$str);
          return '<div class="no-image">'.$str.'</div>';
        } else {
          return $str;
        }       
      } else {
        return '<div class="disable-image">'.$str.'</div>';
      }
    }
  } 
  
  public function background_image($str) {
    
    $html = preg_replace('/<!--(.|\s)*?-->/', '', $str);
    preg_match( '@src="([^"]+)"@' , $html, $match );
    $src = array_pop($match);
    return "background-image: url(".$src.");";
  } 
}