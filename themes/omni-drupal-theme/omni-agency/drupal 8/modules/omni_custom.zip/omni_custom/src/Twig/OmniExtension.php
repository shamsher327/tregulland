<?php
/* COPYRIGHT
------------------------------------------------------------------  
  Omni for Drupal 8.x - Version 1.0                           
  Copyright (C) 2016 esors.com All Rights Reserved.           
  @license - Copyrighted Commercial Software                   
------------------------------------------------------------------  
  Theme Name: Omni Agency                                            
  Author: ESORS                                           
  Date: 19th May 2016                                        
  Website: http://www.esors.com/                              
------------------------------------------------------------------  
  This file may not be redistributed in whole or   
  significant part.                                            
----------------------------------------------------------------*/  
/**
 * @file
 * Contains \Drupal\omni_custom\Twig\OmniExtension. 
 */

namespace Drupal\omni_custom\Twig;

class OmniExtension extends \Twig_Extension {
  
  /**
   * {@inheritdoc}
   */
  public function getName() {
    return 'omni';
  }

  /**
   * {@inheritdoc}
   */
  public function getFunctions() {
    return array(
      new \Twig_SimpleFunction('background_image', array($this, 'background_image'), array('is_safe' => array('html'),)),
    );
  }
  
  public function background_image($str) {
    
    $html = preg_replace('/<!--(.|\s)*?-->/', '', $str);
    preg_match( '@src="([^"]+)"@' , $html, $match );
    $src = array_pop($match);
    return "background-image: url(".$src.");";
  } 
}